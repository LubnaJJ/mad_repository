package com.example.bridal_gown_rental

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
