import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ListProductPage extends StatefulWidget {
  @override
  _ListProductPageState createState() => _ListProductPageState();
}

class _ListProductPageState extends State<ListProductPage> {
  final ImagePicker _picker = ImagePicker();
  XFile? _imageFile;

  // Controllers for text fields
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = pickedFile;
    });
  }

  Future<void> _takePicture() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    setState(() {
      _imageFile = pickedFile;
    });
  }

  Future<void> _listProduct() async {
    if (_imageFile == null ||
        _nameController.text.isEmpty ||
        _descriptionController.text.isEmpty ||
        _quantityController.text.isEmpty ||
        _priceController.text.isEmpty) {
      // Show a snackbar or some error if fields are empty
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please fill in all fields and pick an image.')),
      );
      return;
    }

    // Prepare the data to be sent to the backend
    final uri = Uri.parse('http://10.0.2.2:8000/api/products');
    final request = http.MultipartRequest('POST', uri);

    request.fields['name'] = _nameController.text;
    request.fields['description'] = _descriptionController.text;
    request.fields['quantity'] = _quantityController.text;
    request.fields['price'] = _priceController.text;
    request.fields['business_id'] = '1'; // Replace with actual business ID

    // Attach the image file
    request.files.add(await http.MultipartFile.fromPath('image', _imageFile!.path));

    // Send the request
    final response = await request.send();

    if (response.statusCode == 201) {
      // Successfully listed the product
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Product listed successfully!')),
      );
      Navigator.pop(context); // Navigate back to the business home page
    } else {
      // Handle error response
      final errorMessage = await response.stream.bytesToString();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $errorMessage')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('List a Product')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: _pickImage,
              child: Text('Pick Image from Gallery'),
            ),
            ElevatedButton(
              onPressed: _takePicture,
              child: Text('Take Picture'),
            ),
            _imageFile != null
                ? Image.file(File(_imageFile!.path), height: 150)
                : Container(),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Product Name'),
            ),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            TextField(
              controller: _quantityController,
              decoration: InputDecoration(labelText: 'Quantity'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: _priceController,
              decoration: InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _listProduct,
              child: Text('List Product'),
            ),
          ],
        ),
      ),
    );
  }
}
