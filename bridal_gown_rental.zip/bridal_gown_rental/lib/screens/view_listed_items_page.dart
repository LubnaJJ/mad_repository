import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ViewListedItemsPage extends StatefulWidget {
  @override
  _ViewListedItemsPageState createState() => _ViewListedItemsPageState();
}

class _ViewListedItemsPageState extends State<ViewListedItemsPage> {
  List<dynamic> _products = [];

  @override
  void initState() {
    super.initState();
    _fetchProducts();
  }

  Future<void> _fetchProducts() async {
    final response = await http.get(
      Uri.parse('http://10.0.2.2:8000/api/products'), // Replace with your actual API URL
    );

    if (response.statusCode == 200) {
      try {
        final List<dynamic> productData = json.decode(response.body);

        // Check if the data is not empty and is a list
        if (productData.isNotEmpty) {
          setState(() {
            _products = productData;
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('No products found')),
          );
        }
      } catch (e) {
        print("Error decoding response: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load products')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load products')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Listed Items'),
      ),
      body: _products.isEmpty
          ? Center(child: CircularProgressIndicator())
          : GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, // Two cards in a row
          childAspectRatio: 0.7, // Aspect ratio for the cards
          crossAxisSpacing: 8.0, // Space between the cards
          mainAxisSpacing: 8.0, // Space between rows
        ),
        itemCount: _products.length,
        itemBuilder: (context, index) {
          final product = _products[index];
          final String imageUrl = product['image'] != null
              ? 'http://10.0.2.2:8000/storage/${product['image']}'
              : 'https://via.placeholder.com/150'; // Fallback image URL

          return Card(
            margin: EdgeInsets.all(8.0),
            child: Column(
              children: [
                Image.network(
                  imageUrl,
                  height: 150, // Adjust height to fit the card
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    product['name'] ?? 'No Name',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Text(
                    product['description'] ?? 'No description available',
                    textAlign: TextAlign.center,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    product['price'] != null
                        ? 'LKR ${product['price']}.00'
                        : 'Price unavailable',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.green,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
