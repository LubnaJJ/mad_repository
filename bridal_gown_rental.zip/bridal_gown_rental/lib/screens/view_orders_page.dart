import 'package:flutter/material.dart';

class ViewOrdersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('View Orders')),
      body: Center(child: Text('View Orders Page')),
    );
  }
}
