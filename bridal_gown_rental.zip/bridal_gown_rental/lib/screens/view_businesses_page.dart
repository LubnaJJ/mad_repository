import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'business_detail_page.dart'; // Make sure the path is correct

class ViewBusinessesPage extends StatefulWidget {
  @override
  _ViewBusinessesPageState createState() => _ViewBusinessesPageState();
}

class _ViewBusinessesPageState extends State<ViewBusinessesPage> {
  List<dynamic> _businesses = [];

  @override
  void initState() {
    super.initState();
    _fetchBusinesses();
  }

  Future<void> _fetchBusinesses() async {
    final response = await http.get(Uri.parse('http://10.0.2.2:8000/api/businesses'));

    if (response.statusCode == 200) {
      // Log the response to check the data structure
      print('API Response: ${response.body}');

      setState(() {
        _businesses = json.decode(response.body);
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to load businesses')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Businesses')),
      body: _businesses.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: _businesses.length,
        itemBuilder: (context, index) {
          final business = _businesses[index];

          // Log the business data to check its structure
          print('Business Data: $business');

          // Check the key for the business name
          final businessName = business['business_name'] ?? 'No name provided';

          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              color: Colors.pink[50],
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      businessName,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.pink[900],
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BusinessDetailPage(businessId: business['id']),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.pink[300],
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text('View Details'),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
