import 'package:flutter/material.dart';
import 'list_product_page.dart'; // Import your ListProductPage
import 'view_orders_page.dart';  // Import your ViewOrdersPage
import 'business_info_page.dart'; // Import your BusinessInfoPage
import 'view_listed_items_page.dart'; // Adjust the path as necessary

class BusinessHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Business Home'),
      ),
      body: Column(
        children: [
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ListProductPage()),
              );
            },
            child: Card(
              child: ListTile(
                title: Text('List a Product'),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ViewOrdersPage()),
              );
            },
            child: Card(
              child: ListTile(
                title: Text('View Orders'),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => BusinessInfoPage()),
              );
            },
            child: Card(
              child: ListTile(
                title: Text('Business Info'),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ViewListedItemsPage()),
              );
            },
            child: Card(
              child: ListTile(
                title: Text('View Listed Items'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
