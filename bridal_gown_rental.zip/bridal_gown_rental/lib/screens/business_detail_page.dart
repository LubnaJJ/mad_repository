import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class BusinessDetailPage extends StatefulWidget {
  final int businessId;

  BusinessDetailPage({required this.businessId});

  @override
  _BusinessDetailPageState createState() => _BusinessDetailPageState();
}

class _BusinessDetailPageState extends State<BusinessDetailPage> {
  Map<String, dynamic>? _business;
  List<dynamic> _products = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchBusinessDetails();
  }

  Future<void> _fetchBusinessDetails() async {
    try {
      final response = await http.get(Uri.parse('http://10.0.2.2:8000/api/businesses/${widget.businessId}'));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _business = data;
          _products = data['products'] ?? [];
          _isLoading = false;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to load business details')));
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $error')));
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _rentProduct(int productId) async {
    // Implement the renting logic here
    // This could involve sending an API request to create an order
    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:8000/api/rent'),
        headers: {"Content-Type": "application/json"},
        body: json.encode({"product_id": productId, "user_id": 1}), // Pass appropriate data
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Product rented successfully')));
        // Optionally, update the UI after renting
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to rent product')));
      }
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        title: Text(_business != null ? 'Welcome to ${_business!['name']}' : 'Business Details'),
    ),
    body: _isLoading
    ? Center(child: CircularProgressIndicator())
        : _business == null
    ? Center(child: Text('Failed to load business details'))
        : ListView.builder(
    itemCount: _products.length,
    itemBuilder: (context, index) {
    final product = _products[index];
    return Card(
    child: Column(
    children: [
    Image.network(
    product['image'] ?? 'https://via.placeholder.com/150',
    height: 100,
    width: double.infinity,
    fit: BoxFit.cover,
    errorBuilder: (context, error, stackTrace) {
    return Image.network(
    'https://via.placeholder.com/150', // Fallback if image fails
    height: 100,
    fit: BoxFit.cover,
    );
    },
    ),
    Padding(
    padding: const EdgeInsets.all(8.0),
    child: Text(
    product['name'] ?? 'Unnamed Product',
    style: TextStyle(fontWeight: FontWeight.bold),
    ),
    ),
    Padding(
    padding: const EdgeInsets.all(8.0),
    child: Text(
    product['description'] ?? 'No description available',
    textAlign: TextAlign.center,
    ),
    ),
    Padding(
    padding: const EdgeInsets.all(8.0),
    child: Text(
    'Quantity: ${product['quantity'] ?? 0}',
    style: TextStyle(color: Colors.green),
    ),
    ),
    Padding(
    padding: const EdgeInsets.all(8.0),
    child: Text(
    'Price: LKR ${product['price'] ?? 'N/A'}',
    style: TextStyle(color: Colors.red),
    ),
    ),
    ElevatedButton(
    onPressed: () {
    _rentProduct(product['id']);
    },
    child: Text('Rent Now'),
    ),
    ],
    ),
    );
    },
    ),
    );
  }
}

