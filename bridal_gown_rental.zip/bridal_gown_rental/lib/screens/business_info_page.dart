import 'package:flutter/material.dart';

class BusinessInfoPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Business Information')),
      body: Center(child: Text('Business Information Page')),
    );
  }
}
